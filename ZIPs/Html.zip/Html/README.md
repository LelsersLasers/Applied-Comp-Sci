# HTML assiengmet
Special feature:

- advanced formatting (2 colums wide, stacked side buttons, side by side top buttons)

- multiple pages, with same styling (not correct orginzaztion tho)