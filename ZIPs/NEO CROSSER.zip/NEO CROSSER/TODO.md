# TODO

- E SOUND

- display restore touch directions
- display use w/s up/down to change the selected save

- mouse hover over buttons in restore screen


# 

- "clean" code
    - restores bugtest
        - restore w/h?
            - update hb with w/h
    - duplicate code?
    - for var i vs let i
    - const/let/var
        - scope

- Update directions
- Update README

- Update and redo libary ipad code