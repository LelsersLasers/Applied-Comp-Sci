# TODO
- High scores board
    - use canvas to display 'input name' field
        - touch screen doesn't have keyboard so can't use html input boxes
- Colors/Style
    - On welcome/directions/top scores
    - font?
- Clean up code
- Update directions/read me
#
- Clean code
    - Mr. Bloom approved code
    - Variable name conventions inside code
    - if/for, on one line? or not?
        - make consistent
    - unused code/functions/vars
    - remove console.logs()
    - duplicate code/functions
    - semi-colens
    - let/var/const
- Prep for ipad
    - Movement are buttons by touch
        - confirm current system works
#
