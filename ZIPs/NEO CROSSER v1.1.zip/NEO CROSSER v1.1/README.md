# NEO CROSSER

Directions:
- To start the game double click on 'NEO CROSSER.html'
- It will open in a browser window

Basic Info:
- Use the mouse or the button keys to move navigate menus
	- 'New [G]ame' means pressing 'g' is the same as clicking the button
- Saves work as checkpoints and can be retried from infintely
- The game will work on basically any screen size
	- It will not resize when you resize the window
	- It will only resize when you reload the page

Basic Game Info:
- WASD or arrow keys to move
- Q or 1 teleports you in the direction you are facing
- E or 2 is a togglable movement speed increase
- R or 3 fires lasers in every directions
	- Lasers stun cars, buses, and ufos
	- Running into a stunned object still will kill you
- Tanks can not be stunned
- When you are shot at (later into the game) you will only be stunned
	- After getting stunned, you have temporary stun protection
- Every once and a while a large 'force' might appear
	- It will push you and any cars in a certain direction