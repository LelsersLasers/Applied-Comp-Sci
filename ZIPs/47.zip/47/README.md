# Problem 47

43) 
A coin with a 2-cm diameter is dropped onto a sheet of paper ruled by parallel lines that are 3 cm apart.

Baisc Info:
- Red circles are coins that touch a line
- Green circles are coins that do not touch a line
- The info in the top left displays numberGreen/totalCoins
- Basic settings for the game can be found at the top of 'game.js'
- Window size does not matter, it should work on almost any sized screen
- The random function avoids the use of the % ('modulo') operation
    - Because of the use of random, it might take some time before it gets to the "correct" value