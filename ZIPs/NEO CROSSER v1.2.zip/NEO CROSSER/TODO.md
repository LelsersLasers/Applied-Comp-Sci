# TODO

Fix issue with delta where cars/etc get stuck in walls

Lives system
    - X to start
    - Immunity on rez
    - Every Xk points gain live?
    - And/or live pick ups?
Make HUD Bigger/slightly more central
    - harder to miss
On game 'load' show directions above QER Hud
Warning sign for landslides

Mario Kart speed ups?
Pickup buffs?

On Demand Scaling
- on restore
- on screen change size

Make Thing extend HB?

SETTINGS SCREEN
    - toggle ufos
        - and if they can shoot
    - toggle tanks/buses
    - landslides
    - softcap
    - only set leaderboard if on max settings

display restore touch directions
display use w/s up/down to change the selected save

mouse hover over buttons in restore screen

Let user scroll through all scores (like saves)? (rather than top 10?)

Clarity
- General colors/hitboxes

"Clean" code
- LET
    - scope
- stun protection
- Delta time
- animation code
- shooting code
    - optimize
- restores bugtest
    - restore w/h?
        - update hb with w/h
- duplicate code?
- for var i vs let i
- softCap

Redo any art?
- tanks
- demensions of the textures
Update HitBoxes to match the art
- cars, tanks, ufos

Update directions
Update README