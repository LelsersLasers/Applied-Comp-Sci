# TODO

OPTIMIZE
    - remove "freezes" that freeze the whole broswer
    - Where is time lost? (why so slow?)

On Demand Scaling
- on restore
- on screen change size

Calculate speed/movement based on fps
    

Mario Kart speed ups?

SETTINGS SCREEN
    - toggle ufos
        - and if they can shoot
    - toggle tanks/buses
    - landslides
    - softcap
    - only set leaderboard if on max settings

display restore touch directions
display use w/s up/down to change the selected save

mouse hover over buttons in restore screen

Let user scroll through all scores (like saves)? (rather than top 10?)

Clarity
- General colors/hitboxes
    - Check w/ Jerry/Andrew

"Clean" code
- LET
    - scope
- stun protection
- animation code
- shooting code
    - optimize
- restores bugtest
    - restore w/h?
        - update hb with w/h
- duplicate code?
- for var i vs let i
- softCap

Redo any art?
- tanks
- demensions of the textures
Update HitBoxes to match the art
- cars, tanks, ufos

Update directions
Update README
Update and redo libary ipad code